<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<!--
 ____________________________________________________________
|                                                            |
|    DESIGN : Jeremie Tisseau { http://web-kreation.com }    |
|      DATE : 2008.05.06                                     |
|     EMAIL : webmaster@web-kreation.com                     |
|____________________________________________________________|
-->

<head>
  	<title>Free Web Templates for schools</title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  	<meta name="author" content="Jeremie Tisseau" />
  	<meta name="keywords" content="Free, web, template, free web template, educational, game, school, kids, children" />
  	<meta name="description" content="A free Web Template for schools." />
	<link rel="shorcut icon" href="/favicon.ico" />
	<link rel="stylesheet" href="css/style.css" type="text/css" />
	<!-- Mootools CORE -->
	<script type="text/javascript" src="js/mootools-release-1.11.js"></script>
	<!-- Drop Down Menu - http://dev.visualdrugs.net/mootools/dropdown_menu.html -->
	<script src="js/dropDownMenu.js" type="text/javascript"></script>
		<!--[if IE 7]>
		<style>
		#dropdownMenu li ul ul {
			margin-left: 100px;
		}
		</style>
		<![endif]-->
</head>
<body>
	<div id="container">
		<div id="wrapper">
        <div id="top">
				<div class="logo"><a href="/index.html"><span>EDUCATIONAL</span>SITE</a></div>
				<!-- login -->
				<!-- If you don't need a login section, just delete it below -->
				<ul class="login">
		        	<li class="left">&nbsp;</li>
		        	<li>Hello Guest!</li>
					<li>|</li>
					<li><a href="#">Login</a></li>
					<li>|</li>
					<li><a href="#">Register</a></li>
				</ul> <!-- / login -->
			</div> <!-- / top -->

            <!-- MAIN NAVIGATION -->
			<ul id="nav">
				<li class="left">&nbsp;</li>
            	<li><a class="active" href="index.html" title="Home page">Home</a></li>
				<li>
					<a href="#" title="">Drop Down example <img src="images/nav_bullet.jpg" alt="" /></a>
					<!-- submenu -->
	                <ul>
					   <li><a href="#" title="">Our shcool</a></li>
					   <li><a href="#" title="">Location</a></li>
					   <li><a href="#" title="">Staff</a></li>
					</ul>
				</li> <!-- /end Drop Down Example -->
				<li>
					<a href="#" title="">Topics <img src="images/nav_bullet.jpg" alt="" /></a>
					<!-- submenu -->
	                <ul>
					   <li><a href="#" title="">Math</a></li>
					   <li><a href="#" title="">English</a></li>
					   <li><a href="#" title="">Art &amp; Music</a></li>
					   <li><a href="#" title="">Science &amp; Tech</a></li>
					</ul>
				</li>
            	<li><a href="index.html" title="">Teachers Space</a></li>
            	<li><a href="index.html" title="">Parents Space</a></li>
				<li><a href="contact.php" title="Contact Us">Contact Us</a></li>
				<li class="sep">&nbsp;</li>
				<li class="right">&nbsp;</li>
			</ul>
			<!-- / END MAIN NAVIGATION -->

			<!-- HEADER -->
			<!-- image of the kids by horizontal.integration: http://flickr.com/photos/ebolasmallpox/1066368855/in/set-72157601353861692/ -->
			<div id="header">
				<div class="intro">
					<h2>Your Company Name</h2>
					<h1>Your nice and fancy slogan</h1>
					<p>And finally, a short introduction. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...</p>
				<form method="get" id="searchform" action="http://www.google.com/search">
					<div>
					<input class="searchField" type="text" value="" name="q" />
					<input class="searchSubmit" type="submit" value="" />
					<!-- If you want the search form to search your site, change "web-kreation.com" by the url of your site"-->
                    <input type="hidden" name="sitesearch" value="web-kreation.com" />
					</div>
				</form>
				</div> <!-- / intro -->
			</div> <!-- /header -->


			<!-- CONTENT -->
			<div id="content"> <!-- The contact form starts here-->
                <?php
                     $error    = ''; // error message
                     $name     = ''; // sender's name
                     $email    = ''; // sender's email address
                     $subject  = ''; // subject
                     $message  = ''; // the message itself
                     $spamcheck = ''; // Spam check

                if(isset($_POST['send']))
                {
                     $name     = $_POST['name'];
                     $email    = $_POST['email']; //'email' must be the same as name="email" in the input
                     $subject  = $_POST['subject'];
                     $message  = $_POST['message'];
                     $spamcheck = $_POST['spamcheck'];

                    if(trim($name) == '')
                    {
                        $error = '<div class="error">Please enter your name!</div>';
                    }
                	  else if(trim($email) == '')
                    {
                        $error = '<div class="error">Please enter your email address!</div>';
                    }
                    else if(!isEmail($email))
                    {
                        $error = '<div class="error">You have enter an invalid e-mail address. Please, try again!</div>';
                    }
                	  else if(trim($subject) == '')
                    {
                        $error = '<div class="error">Please enter a subject!</div>';
                    }
                	  else if(trim($message) == '')
                    {
                        $error = '<div class="error">Please enter your message!</div>';
                    }
                	  else if(trim($spamcheck) == '')
                    {
                        $error = '<div class="error">Please enter the number for Spam Check!</div>';
                    }
                	  else if(trim($spamcheck) != '5')
                    {
                        $error = '<div class="error">Spam Check: The number you entered is not correct! 2 + 3 = ????</div>';
                    }
                    if($error == '')
                    {
                        if(get_magic_quotes_gpc())
                        {
                            $message = stripslashes($message);
                        }

                        // make sure to change the email address below or you will nver receive mails
                        // the email will be sent to:
                        $to      = "yourname@domain.com";

                        // the email subject
                        // '[Contact Form] :' will appear automatically in the subject.
                        // You can change the text if you wish.
                        $subject = '[Contact Form] : ' . $subject;

                        // the mail message ( add any additional information if you want )
                        $msg     = "$message";

						//Extras: User info (Optional!)
						//Delete this part if you don't need it
						//Display user information such as Ip address and browsers information...
						$msg .= " \r\n\n---User information--- \r\n"; //Title
						$msg .= "User IP : ".$_SERVER["REMOTE_ADDR"]."\r\n"; //Sender's IP
						$msg .= "Browser info : ".$_SERVER["HTTP_USER_AGENT"]."\r\n"; //User agent
						$msg .= "User come from : ".$_SERVER["HTTP_REFERER"]; //Referrer
						// END Extras

                        mail($to, $subject, $msg, "From: $name <$email>\r\nReply-To: $name <$email>\r\nReturn-Path: $email\r\n");
                ?>

                    <!-- Message sent! (change the text below as you wish)-->
                    <h1>Congratulations!!</h1>
                       <p>Thank you <b><?=$name;?></b>, your message is sent! We will get back to you as soon as possible.</p>
					   <p>Return to the <a href="index.html">home page</a> or use the navigation above.</p>
                    <!--End Message Sent-->

            <?php
                }
            }
            if(!isset($_POST['send']) || $error != '')
            {
            ?>


                <h1>Contact Us!</h1>

                <p>Do you have a question, comment, suggestion or news tip to pass along to our school? If so, fill out the form below: </p>

				<p>We will be glad to answer any of your questions or suggestions. Thanks.</p>

				<p class="note">In order to use this form, open this page in a web editor and change the email address line 145: <code>$to      = "yourname@domain.com";</code></p>

            <!--Error Message-->
            <?=$error;?>

                <form class="contact"  method="post" name="contFrm" id="contFrm" action="">

                    <label><span class="red">*</span> Full Name:</label>
          			<input name="name" type="text" class="box" id="name" size="40" value="<?=$name;?>" />

          			<label><span class="red">*</span> Email:</label>
          			<input name="email" type="text" class="box" id="email" size="40" value="<?=$email;?>" />

          			<label><span class="red">*</span> Subject:</label>
          			<input name="subject" type="text" class="box" id="subject" size="40" value="<?=$subject;?>" />

               		<label><span class="red">*</span> Message:</label>
               		<textarea name="message" cols="50" rows="6"  id="message"><?=$message;?></textarea><br />

                   	<label><span class="red">*</span> Spam check: <b>2 + 3= </b></label>
                    <input name="spamcheck" type="text" class="box" id="spamcheck" size="4" value="<?=$spamcheck;?>" />

          			<!-- Submit Button-->
               		<input name="send" type="submit" class="button" id="send" value=""  />

                </form>

		          <!-- E-mail verification. Do not modify the code below this line -->
		          <?php
		          }

		          function isEmail($email)
		          {
		              return(preg_match("/^[-_.[:alnum:]]+@((([[:alnum:]]|[[:alnum:]][[:alnum:]-]*[[:alnum:]])\.)+(ad|ae|aero|af|ag|ai|al|am|an|ao|aq|ar|arpa|as|at|au|aw|az|ba|bb|bd|be|bf|bg|bh|bi|biz|bj|bm|bn|bo|br|bs|bt|bv|bw|by|bz|ca|cc|cd|cf|cg|ch|ci|ck|cl|cm|cn|co|com|coop|cr|cs|cu|cv|cx|cy|cz|de|dj|dk|dm|do|dz|ec|edu|ee|eg|eh|er|es|et|eu|fi|fj|fk|fm|fo|fr|ga|gb|gd|ge|gf|gh|gi|gl|gm|gn|gov|gp|gq|gr|gs|gt|gu|gw|gy|hk|hm|hn|hr|ht|hu|id|ie|il|in|info|int|io|iq|ir|is|it|jm|jo|jp|ke|kg|kh|ki|km|kn|kp|kr|kw|ky|kz|la|lb|lc|li|lk|lr|ls|lt|lu|lv|ly|ma|mc|md|mg|mh|mil|mk|ml|mm|mn|mo|mp|mq|mr|ms|mt|mu|museum|mv|mw|mx|my|mz|na|name|nc|ne|net|nf|ng|ni|nl|no|np|nr|nt|nu|nz|om|org|pa|pe|pf|pg|ph|pk|pl|pm|pn|pr|pro|ps|pt|pw|py|qa|re|ro|ru|rw|sa|sb|sc|sd|se|sg|sh|si|sj|sk|sl|sm|sn|so|sr|st|su|sv|sy|sz|tc|td|tf|tg|th|tj|tk|tm|tn|to|tp|tr|tt|tv|tw|tz|ua|ug|uk|um|us|uy|uz|va|vc|ve|vg|vi|vn|vu|wf|ws|ye|yt|yu|za|zm|zw)$|(([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5])\.){3}([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5]))$/i"
		                      ,$email));
		          }
		          ?>

				<a class="backToTop" href="#" title="Back To Top">&nbsp;</a>
			</div> <!-- / content -->

			<!-- SIDEBAR -->
			<div id="sidebar">
				<h2>News &amp; Announcements</h2>
					<ul id="news">
                    	<li>
							<!-- images must be 54x54px -->
							<a href="#" title="Some title"><!-- img by foreversouls --><img src="images/temp/news1.jpg" alt="" width="54" /> </a>
                        	<h3>News Heading H3</h3>
							<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium... <br />
							<a href="#" title="More">More &raquo;</a></p>
						</li>
                    	<li>
							<!-- images must be 54x54px -->
							<a href="#" title="Some title"><!-- img by foreversouls --><img src="images/temp/news2.jpg" alt="" width="54" /> </a>
                        	<h3>News Heading H3</h3>
							<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium... <br />
							<a href="#" title="More">More &raquo;</a></p>
						</li>
                    	<li>
							<!-- images must be 54x54px -->
							<a href="#" title="Some title"><!-- img by Baston --><img src="images/temp/news3.jpg" alt="" width="54" /> </a>
                        	<h3>News Heading H3</h3>
							<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium... <br />
							<a href="#" title="More">More &raquo;</a></p>
						</li>
					</ul>

					<!-- Ads -->
					<h2>Advertising</h2>
                        <!-- Replace this by your own google ad. Well if you don't, I don't mind :-) -->
			            <script type="text/javascript"><!--
						google_ad_client = "pub-4856360357265098";
						google_ad_slot = "1960811671";
						google_ad_width = 200;
						google_ad_height = 200;
						//-->
						</script>
						<script type="text/javascript"
						src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
						</script>
			</div> <!-- / Sidebar -->




			<!-- Footer -->
			<div id="footer">
				<div class="foot_l"><a href="http://web-kreation.com" title="Wordpress theme Designed by Web-Kreation.com">&nbsp;</a></div>
				<div class="foot_content">
					<ul>
						<li><a href="#">Home</a></li>
						<li><a href="#">About Us</a></li>
						<li><a href="#">Parents</a></li>
						<li><a href="#">Teachers</a></li>
						<li><a href="#">Contact Us</a></li>
					</ul>
					<p>All contents copyright &copy; YourName. All rights reserved.</p>
				</div>
				<div class="foot_r">&nbsp;</div>

				<div class="backToTop">
					<a class="backToTop" href="#" title="Back To Top">&nbsp;</a>
				</div>

				<div class="foot_info">
					<p>Valid <a href="http://validator.w3.org/check?uri=referer" title="validate XHTML">XHTML</a> &amp; <a href="http://jigsaw.w3.org/css-validator" title="validate CSS">CSS</a>. Template by <a href="http://web-kreation.com" title="Web-kreation.com">Web-kreation</a></p>
				</div>
			</div><!-- / footer -->

<!-- Night Transition designed by Jeremie Tisseau - http://web-kreation.com/download.php#nighttransition/ -->
		</div><!-- / wrapper -->
	</div><!-- / container -->
</body>
</html>